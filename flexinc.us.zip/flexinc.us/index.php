<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="icon" href="img/fav-icon.png" type="image/x-icon" />
        <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
        <title>Flex</title>

        <!-- Icon css link -->
        <link href="css/font-awesome.min.css" rel="stylesheet">
        <link href="vendors/elegant-icon/style.css" rel="stylesheet">
        <link href="vendors/themify-icon/themify-icons.css" rel="stylesheet">
        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Rev slider css -->
        <link href="vendors/revolution/css/settings.css" rel="stylesheet">
        <link href="vendors/revolution/css/layers.css" rel="stylesheet">
        <link href="vendors/revolution/css/navigation.css" rel="stylesheet">
        <link href="vendors/animate-css/animate.css" rel="stylesheet">

        <!-- Extra plugin css -->
        <link href="vendors/owl-carousel/owl.carousel.min.css" rel="stylesheet">

        <link href="css/style.css" rel="stylesheet">
        <link href="css/responsive.css" rel="stylesheet">

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <!--================Search Area =================-->
        <!--<section class="search_area">
            <div class="search_inner">
                <input type="text" placeholder="Enter Your Search...">
                <i class="ti-close"></i>
            </div>
        </section>-->
        <!--================End Search Area =================-->
        
        <!--================Header Menu Area =================-->
        <header class="main_menu_area">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand" style="margin: 0 auto;" href="#"><img src="img/logo.png" alt=""></a>
                
                <ul class="navbar-nav justify-content-end">
                    <li><a href="#"><i class="icon_search"></i></a></li>
                </ul>
            </nav>
        </header>
        <!--================End Header Menu Area =================-->

        <!--================Slider Area =================-->
        <section class="main_slider_area">
            <div id="main_slider" class="rev_slider" data-version="5.3.1.6">
                <ul>
                    <li data-index="rs-2947" data-transition="slidevertical" data-slotamount="1" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="1000"  data-rotate="0"  data-fstransition="fade" data-fsmasterspeed="1500" data-fsslotamount="7" data-saveperformance="off"  data-title="Intro" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                    <!-- MAIN IMAGE -->
                        <img src="img/home-slider/slider-1.jpg"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
                        <!-- LAYER NR. 1 -->
                        <div class="slider_text_box f1">
                            <div class="tp-caption tp-resizeme secand_text"
                                data-x="['center','center','center','center','center','center']"
                                data-hoffset="['100','80','80','0']"
                                data-y="['middle','middle','middle','middle']"
                                data-voffset="['-100','0','0','0','0']"
                                data-fontsize="['48','48','48','28','28','22']"
                                data-lineheight="['50','60','60','36','36','30']"
                                data-width="100%"
                                data-height="none"
                                data-whitespace="normal"
                                data-type="text"
                                data-responsive_offset="on"
                                data-transform_idle="o:1;"
                                data-frames="[{&quot;delay&quot;:10,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;&quot;,&quot;mask&quot;:&quot;x:0px;y:[100%];s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;y:[175%];&quot;,&quot;mask&quot;:&quot;x:inherit;y:inherit;s:inherit;e:inherit;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;}]"
                                data-textAlign="['left','left','left','left','left','left']"

                                style="z-index: 8;">
                                
                                <font style="font-family:'Poppins', sans-serif;font-weight:300;color:#fff;">A lifestyle app for drivers, <br />riders, & peer to peer. </font>
                                <br/><font style="line-height:0px;font-family:'Poppins', sans-serif;font-weight:100;color:#fff;font-size:24px;">From exotic to budget friendly options, </font>
                                <br/><font style="line-height:0px;font-family:'Poppins', sans-serif;font-weight:100;color:#fff;font-size:24px;">we offer the best experience car sharing options can</font>
                                <br/><font style="line-height:0px;font-family:'Poppins', sans-serif;font-weight:100;color:#fff;font-size:24px;">offer for both riders and drivers.</font>
                                <br/><font style="line-height:0px;font-family:'Poppins', sans-serif;font-weight:150;color:#fff;font-size:26px;">Our services include but not limited to:‍</font>
                                <br/><font style="line-height:0px;font-family:'Poppins', sans-serif;font-weight:100;color:#fff;font-size:24px;">&nbsp;&nbsp;&nbsp;&nbsp;&#8226;&nbsp;Driver Incentives</font>
                                <br/><font style="line-height:0px;font-family:'Poppins', sans-serif;font-weight:100;color:#fff;font-size:24px;">&nbsp;&nbsp;&nbsp;&nbsp;&#8226;&nbsp;Flexible Payment Options</font>
                                <br/><font style="line-height:0px;font-family:'Poppins', sans-serif;font-weight:100;color:#fff;font-size:24px;">&nbsp;&nbsp;&nbsp;&nbsp;&#8226;&nbsp;Financing Options for Riders and Drivers</font>
                                <br/><font style="line-height:0px;font-family:'Poppins', sans-serif;font-weight:100;color:#fff;font-size:24px;">&nbsp;&nbsp;&nbsp;&nbsp;&#8226;&nbsp;Peer to Peer Car Sharing and more....!</font>
                                <br/><font style="line-height:0px;font-family:'Poppins', sans-serif;font-weight:150;color:#fff;font-size:26px;">Download the App and Try Flex today!</font>
                                
                            </div>

                            <div class="slider_text_box f2">
                                <div class="tp-caption tp-resizeme secand_text"
                                    data-x="['center','center','center','center','center','center']"
                                    data-hoffset="['100','80','80','0']"
                                    data-y="['middle','middle','middle','middle']"
                                    data-voffset="['230','0','0','0','0']"
                                    data-fontsize="['48','48','48','28','28','22']"
                                    data-lineheight="['50','60','60','36','36','30']"
                                    data-width="100%"
                                    data-height="none"
                                    data-whitespace="normal"
                                    data-type="text"
                                    data-responsive_offset="on"
                                    data-transform_idle="o:1;"
                                    data-frames="[{&quot;delay&quot;:10,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;&quot;,&quot;mask&quot;:&quot;x:0px;y:[100%];s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:1500,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;y:[175%];&quot;,&quot;mask&quot;:&quot;x:inherit;y:inherit;s:inherit;e:inherit;&quot;,&quot;ease&quot;:&quot;Power2.easeInOut&quot;}]"
                                    data-textAlign="['left','left','left','left','left','left']"
    
                                    style="z-index: 8;">
                                    
                                    <a href="#" target="_blank"><img src="img/ios.png"/></a> <a href="https://play.google.com/store/apps/details?id=com.app.flexinc" target="_blank"><img src="img/appstore.png"/></a>
                                </div>
                        </div>
                    </li>
                </ul>
            </div>
        </section>
        <!--================End Slider Area =================-->

        <!--================Creative Feature Area =================-->
        <section class="creative_feature_area">
            <div class="container">
                <div class="c_feature_box" style="background: content-box;text-align: center;">
                    <div class="row">                        
                        <div class="col-lg-12">
                            <div class="c_box_item">
                                <img src="img/overlay.png"/>
                            </div>
                        </div>                        
                    </div>
                </div>
                <div class="digital_feature" style="margin-top: 100px;">
                    <div class="row">
                        <div class="col-lg-5">
                            <div class="d_feature_img">
                                <img src="img/feature-right.jpg" alt="">
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div class="d_feature_text" style="margin-top: 50px;">
                                <div class="main_title">
                                    <h1><Strong>How does Flex work?</Strong></h1>
                                </div>
                                <h3>Step 1</h3>
                                <p style="font-size: 22px;">Download the app on iOS or Android</p>
                                <br/>
                                <h3>Step 2</h3>
                                <p style="font-size: 22px;">Create an Account</p>
                                <br/>
                                <h3>Step 3</h3>
                                <p style="font-size: 22px;">Choose a Destination</p>
                                <br/>
                                <h3>Step 4</h3>
                                <p style="font-size: 22px;">Kick back and enjoy your first ride - Free!</p>
                                <br/>

                                <p style="font-size: 22px;line-height: 30px;"><Strong>Drivers must provide vehicle photos, government issued ID, proof of insurance (we can provide). Drivers automatically qualify for peer to peer carrental sharing.</Strong></p>
                            </div>                        
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--================End Creative Feature Area =================-->
        
        <!--================Testimonials Area =================-->
        <section class="testimonials_area" style="margin-top:100px;">
            <div class="container">
                <h1><strong>Careers</strong></h1>
                <div class="testimonials_slider owl-carousel">
                    <div class="item">
                        <div class="media">
                            <div class="media-body">
                                <h3 style="color: hsla(166.176, 100%, 40%, 1);">App Developer</h3>
                                <p>We are looking for a collaborative, problem solving iOS developer. Your primary focus will be development of iOS applications for and their integration with back-end services, working alongside other engineers and developers working on different layers of the infrastructure.</p>
                                
                                <h4><a style="background-color: hsla(166.176, 100%, 40%, 1);display: inline-block;    color: white;
                                    border: 0;line-height: inherit;text-decoration: none;cursor: pointer;padding: 9px 15px;" target="_blank" href="https://angel.co/company/flex-11/jobs/565274-full-stack-ios-android-developer">Apply</a></h4>
                            </div>
                            <img class="d-flex" src="img/testimonials-1.png" style="width:400px;" alt="">                            
                        </div>
                    </div>
                    <div class="item">
                        <div class="media">
                            <div class="media-body">
                                <h3 style="color: hsla(166.176, 100%, 40%, 1);">Micro-Influencer</h3>
                                <p>We are seeking a professional, reliable, enthusiastic brand ambassador to join our growing company. In this role, you will serve as the face and voice of our company, build brand recognition, and successfully promote our products and services. You will communicate and engage with customers, both online and offline, in meaningful ways to increase our company’s brand awareness and add generate new sales opportunities.</p>
                                
                                <h4><a style="background-color: hsla(166.176, 100%, 40%, 1);display: inline-block;    color: white;
                                    border: 0;line-height: inherit;text-decoration: none;cursor: pointer;padding: 9px 15px;" target="_blank" href="https://angel.co/company/flex-11/jobs/573491-brand-ambassador-promotional-sales-model">Apply</a></h4>
                            </div>
                            <img class="d-flex" src="img/testimonials-2.png" style="width:400px;" alt="">                            
                        </div>
                    </div>
                    <div class="item">
                        <div class="media">
                            <div class="media-body">
                                <h3 style="color: hsla(166.176, 100%, 40%, 1);">Graphic Designer/Web Designer</h3>
                                <p>We are looking for a talented Designer to create amazing user experiences. The ideal candidate should have an eye for clean and artful design. They should also have superior user interface design skills. The successful candidate will be able to translate high-level requirements into interaction flows and artifacts. They will be able to transform them into beautiful, intuitive, and functional designs.</p>
                                
                                <h4><a style="background-color: hsla(166.176, 100%, 40%, 1);display: inline-block;    color: white;
                                    border: 0;line-height: inherit;text-decoration: none;cursor: pointer;padding: 9px 15px;" target="_blank" href="https://angel.co/company/flex-11/jobs/565275-web-designer-graphic-designer">Apply</a></h4>
                            </div>
                            <img class="d-flex" src="img/testimonials-3.png" style="width:400px;" alt="">                            
                        </div>
                    </div>
                    <div class="item">
                        <div class="media">
                            <div class="media-body">
                                <h3 style="color: hsla(166.176, 100%, 40%, 1);">CTO</h3>
                                <p>Overseeing all technical aspects of the company, the CTO works with Executive Management to grow the company through the use of technological resources. Using an active and practical approach, the CTO will direct all employees in IT and IO departments to attain the company’s strategic goals established in the company’s strategic plan.</p>
                                
                                <h4><a style="background-color: hsla(166.176, 100%, 40%, 1);display: inline-block;    color: white;
                                    border: 0;line-height: inherit;text-decoration: none;cursor: pointer;padding: 9px 15px;" target="_blank" href="https://angel.co/company/flex-11/jobs/578821-chief-technology-officer-cto">Apply</a></h4>
                            </div>
                            <img class="d-flex" src="img/testimonials-4.png" style="width:400px;" alt="">                            
                        </div>
                    </div>
                    <div class="item">
                            <div class="media">
                                <div class="media-body">
                                    <h3 style="color: hsla(166.176, 100%, 40%, 1);">Join our fast growing team!</h3>
                                    <p>Now hiring for Customer Service Representatives, Web Designers, IT Project Managers/Developers, and Administrative Assistants.</p>
                                    
                                    <h4><a style="background-color: hsla(166.176, 100%, 40%, 1);display: inline-block;    color: white;
                                        border: 0;line-height: inherit;text-decoration: none;cursor: pointer;padding: 9px 15px;" target="_blank" href="https://angel.co/company/flex-11/jobs">View More</a></h4>
                                </div>
                                <img class="d-flex" src="img/testimonials-5.png" style="width:400px;" alt="">                            
                            </div>
                        </div>
                </div>
            </div>
        </section>
        <!--================End Testimonials Area =================-->

        <!--================Latest News Area =================-->
        <section class="latest_news_area">
            <div class="container" style="height:500px;">
                <iframe src="https://www.youtube.com/embed/OCauQ1sARZY?rel=0&amp;controls=1&amp;autoplay=0&amp;mute=0&amp;start=0" frameborder="0" allowfullscreen="" style="left: 0px; top: 0px; width: 100%; height: 100%; pointer-events: auto;"></iframe>
            </div>
        </section>
        <!--================End Latest News Area =================-->

        <!--================Footer Area =================-->
        <footer class="footer_area">
            <p align="center" style="margin-top:50px;">
                <!--<iframe src="https://eventbrite.com/tickets-external?eid=65365972383&amp;ref=etckt" width="50%" height="105px" class="fw-iframe" scrolling="no" frameborder="0"></iframe>-->
            </p>
            <div id="eventbrite-widget-container-65365972383"></div>
            <div class="footer_widgets_area">
                <div class="container">
                    <div class="f_widgets_inner row">
                        <div class="col-lg-3 col-md-6" style="margin: 0 auto;">
                            <aside class="f_widget subscribe_widget">
                                <div class="f_w_title">
                                    <h3>Subscription</h3>
                                </div>
                                <div class="input-group">
                                    <input name="emailText" id="emailText" type="email" class="form-control"  placeholder="E-mail" aria-label="E-mail">
                                    <span class="input-group-btn">
                                        <button class="btn btn-secondary submit_btn" type="button" onclick="submitEmail();">Subscribe</button>
                                    </span>
                                </div>
                                <ul>
                                    <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                </ul>
                            </aside>
                        </div>
                    </div>
                </div>
            </div>
            <div class="copy_right_area">
                <div class="container">
                    <div class="float-md-left">
                        <h5>Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved , Flex Inc</h5>
                    </div>
                    <div class="float-md-right">
                        <ul class="nav">
                            <li class="nav-item">
                                <a class="nav-link active" href="javascript:terms()">Terms and Conditions</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="javascript:privacy()">Privacy Policy</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
        <!--================End Footer Area =================-->

        <div class="modal fade" id="terms_modal" tabindex="-1" role="dialog">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h4 class="modal-title">Terms and Conditions</h4>
              </div>
              <div class="modal-body">
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><b style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial;color:black'>Please read the following Terms carefully before using</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> <b style='mso-bidi-font-weight:
                normal'>FLEX, Inc.’s (“FLEX”, “our” or “we”) web site, www.flexinc.us,
                including but not limited to the Web Site, as well as any online features,
                services and/or programs offered by FLEX (collectively, the “Web Site”).</b> By
                accessing or using the Web Site, you agree to the following Terms. You should
                review these Terms regularly as they may change at any time at the sole
                discretion of FLEX. If you do not agree to any portion of these Terms, you
                should not access or otherwise use the Web Site. “Content” refers to any text,
                materials, documents, images, graphics, logos, design, audio, video and any
                other information provided from or on, uploaded to and/or downloaded from the
                Web Site.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>We will make an
                effort to update this web page with any changes to these Terms and/or to the
                services described in these Terms and you are encouraged to review these Terms
                frequently (the date of the most recent revision to these Terms appear at the
                end of these Terms).</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>Terms related to
                Online Account Access to your account(s) that you have with FLEX (“Account”) is
                set forth in Paragraph 3 herein.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l0 level1 lfo1;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'><span
                style='mso-spacerun:yes'> </span>1.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>CONVENIENCE AND INFORMATION ONLY;
                ACCEPTANCE OF TERMS.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>
                By merely providing access to the Web Site, FLEX does not warrant or represent
                that: (a) the Content is accurate, complete, up-to-date or current; (b) FLEX
                has any obligation to update any Content; (c) the Content is free from
                technical inaccuracies or typographical errors; (d) that the Content does not
                infringe on the intellectual property rights of any third party; (e) that the
                Content is free from changes caused by a third party; (f) your access to the
                Web Site will be free from interruptions, errors, computer viruses or other
                harmful components; and/or (g) any information obtained in response to
                questions asked through, or postings made on, the Web Site is accurate or
                complete. Your use of the Web Site and the services offered therein are subject
                to federal law, the law of the state where FLEX maintains your Account, or, if
                FLEX transfers your Account to another location, where FLEX currently maintains
                your Account (“Applicable Law”).</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:3.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>You affirm that you are either more
                than 18 years of age, or an emancipated minor, or possess legal parental or
                guardian consent, and are fully able and competent to enter into the terms,
                conditions, obligations, affirmations, representations, and warranties set
                forth in these Terms, and to abide by and comply with these Terms. In any case,
                you affirm that you are over the age of 13, as <b style='mso-bidi-font-weight:
                normal'>THE WEB SITE IS NOT INTENDED FOR CHILDREN UNDER 13 THAT ARE
                UNACCOMPANIED BY HIS OR HER PARENT OR LEGAL GUARDIAN</b>.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l0 level1 lfo1;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'><span
                style='mso-spacerun:yes'> </span>2.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>SITE USE AND CONTENT.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> You may view pages from the Web
                Site solely for personal, non-commercial purposes. You may not otherwise use,
                modify, copy, print, display, reproduce, distribute or publish any information
                from the Web Site without the express, prior, written consent of FLEX. At any
                time, we may, without further notice, make changes to the Web Site, to these Terms
                and/or to the services described in these Terms.</span><span style='font-size:
                10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l0 level1 lfo1;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'><span
                style='mso-spacerun:yes'> </span>3.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>USER ACCOUNT, PASSWORD, SECURITY AND
                ELECTRONIC ACCOUNT SERVICES.</span></b><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(a)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>DEFINITIONS.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> The following definitions govern
                the terms of this Paragraph 3 and as used elsewhere in these Terms:</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l2 level1 lfo3;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Bill Payment Cutoff Time</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> means 11:59 p.m. Central Time on
                any Business Day and is the time by which you must transmit Payment
                Instructions for such Payment Instructions to be considered effective for that
                particular Business Day.</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l3 level1 lfo4;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Business Day</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> means every day except Saturdays
                and Sundays and federal holidays.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l4 level1 lfo5;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Payment Account</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> means your personal or business
                checking, savings, or money market account from which FLEX bill payments for
                your Account(s) may be made by you. FLEX recommends that you confirm with your
                banking institution any fees that you may be changed for bill payments from
                your Payment Account before designating a banking account as a Payment Account
                (<i style='mso-bidi-font-style:normal'>e.g.</i>, your money market account may
                permit a limited number of transfers before fees are imposed).</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l5 level1 lfo6;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Payee</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> means FLEX or its subsidiary to
                which you direct a payment.</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l6 level1 lfo7;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Payment Instructions</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> means the information provided by
                you for a bill payment to be made to Payee (<i style='mso-bidi-font-style:normal'>i.e.</i>,
                banking account number, ABA number, payment date, payment amount, and any
                additional information).</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l7 level1 lfo8;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Payment Due Date</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> means the Business Day of your
                choice and as designated by you upon which your payment will be received by
                Payee and your Payment Account will be debited. <b style='mso-bidi-font-weight:
                normal'>Note:</b> Your Payment Due Date may be no later than the “Due Date” set
                by FLEX for your most current bill.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l8 level1 lfo9;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Pending Bill Payment</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> means a pending bill payment
                authorized by you through the Online Service that has not been debited to your
                Payment Account.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(b)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>ONLINE
                ACCOUNT ACCESS.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>
                For certain types of features available through the Web Site, including the
                Online Account Access features (the “Online Service”), we require the use of
                encryption technologies provided for your protection and/or your use of a user
                identification name (“UserID”) and password after setting up a user account (“User
                Account”). The Online Service is available by clicking on the Online Account
                Access login at www.flexinc.us. For self-enrollment, you must provide
                Account-specific information to authenticate yourself (e.g., Account owner name
                and address, Account number and meter number). You will be asked
                Account-specific information to authenticate yourself. In these Terms, “you”
                and “<span class=GramE>your</span>” refer to each person, or, if applicable,
                the entity who is an owner, signer, or has unrestricted access to a User
                Account and each person that uses the Online Service with your permission
                (“Authorized User”). You may never use another person’s User Account and/or
                UserID without permission. When your Online Service is linked to one or more
                Accounts, FLEX may act on the oral, written, or electronic instructions of any
                authorized signer regarding your service for those Accounts. It is your
                responsibility to notify FLEX if an Authorized User should no longer be given
                access to an Account through the Online Service.</span><span style='font-size:
                10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(c)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>USER
                ACCOUNT AND PASSWORD.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>
                We use reasonable precautions to protect the privacy of your UserID, password
                and User Account information by utilizing a Secure Socket Layer (“SSL”)
                connection. Accordingly, your UserID, password and User Account information are
                encrypted using an SSL connection and are not expected to be read in an
                intelligible form as they travel to the Web Site. You, however, are ultimately
                responsible for protecting your UserID, password and User Account information
                from disclosure to third parties, and you are not permitted to circumvent the
                use of required encryption technologies. You are required to take reasonable
                precautions to safeguard your UserID and password. You agree to never leave
                your computer unattended while using the Online Service and to always exit the
                Online Service by clicking on “Log Out.” You also agree to immediately notify
                FLEX of any unauthorized use of your UserID, password and/or User Account, or
                any other breach of security by email at <span style='background:yellow;
                mso-highlight:yellow'>______________________ @______________________.</span>com,
                or through the online message center (if applicable). You are solely
                responsible for any activity that occurs with respect to your User Account and
                UserID. While we provide certain encryption technologies and use other
                reasonable precautions to protect your confidential information and provide
                suitable security, we do not and cannot guarantee or warrant that information
                transmitted through the Internet is secure, or that such transmissions are free
                from delay, error, interception or interruption.</span><span style='font-size:
                10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(d)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>RELIANCE
                BY FLEX.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'> You
                authorize FLEX to rely on your UserID and password to identify you when you use
                the Online Service, and as signature authorization for any payment made using
                the Online Service. You acknowledge and agree that you are responsible for all
                payments you make using the Online Service and for paying any and all late
                charges or penalties. You also acknowledge and agree that if you permit another
                person or persons to use the Online Service or give them your UserID and/or
                password, you are responsible for any payment that person makes to your
                Account, even if the person exceeds your authorization. You agree that FLEX may
                comply with the Payment Instructions entered by any person using your UserID
                and Password, subject to the terms set forth more fully below in the
                Unauthorized Payments section of these Terms.</span><span style='font-size:
                10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(e)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>SECURITY.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> FLEX is committed to protecting the
                security and confidentiality of information about you and your Account and User
                Account. FLEX uses, and may in the future use, several different security
                methods to protect your Account and User Account information, including:</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l9 level1 lfo10;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>You
                can only access the Online Service with certain browsers that have high
                security standards.</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l10 level1 lfo11;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>If
                the Online Service does not recognize your computer, you will be prompted to answer
                one of your challenge questions to verify your identity.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l11 level1 lfo12;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>The
                Online Service will automatically log off if prolonged periods of inactivity
                occur.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l12 level1 lfo13;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>Your
                session will terminate if you navigate away from the Online Service to another
                website.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(f)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>ELECTRONIC
                COMMUNICATION.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l13 level1 lfo14;tab-stops:list 74.0pt'><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'><span
                style='mso-list:Ignore'>(i)<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span></b><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Email and Online Message Center.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> When you enroll in the Online
                Service, you must designate a primary email address that will be used for
                receiving electronic communication. To the extent that FLEX maintains an online
                message center now or in the future, such exchange of communications shall be
                considered an electronic communication and may be utilized by FLEX for
                providing you notices pursuant to these Terms, as required by Applicable Law
                (as permitted) or generally regarding your Account(s) with FLEX. FLEX will
                NEVER send you email requesting confidential information such as Account
                numbers, usernames, or passwords and you should NEVER respond to any email
                requesting such information. If you receive such an email purportedly from
                FLEX, do not respond to the email and forwarding the email to <span
                style='background:yellow;mso-highlight:yellow'>______________________
                @______________________.com</span>.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l14 level1 lfo15;tab-stops:list 74.0pt'><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'><span
                style='mso-list:Ignore'>(ii)<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
                </span></span></span></b><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Usage of Electronic Communication.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> By your enrollment in the Online
                Service, you agree to receive these Terms and any disclosures or notices
                required by Applicable Law and all other communications electronically to the
                email address you designate in your account profile. You also agree that FLEX
                may respond to any communication you send to FLEX with an electronic
                communication, regardless of whether your original communication with FLEX was
                an electronic communication. Any electronic communication FLEX sends to you
                will be considered received within three (3) calendar days of the date such
                communication is sent by computer servers utilized by FLEX to the email address
                you designate in your account profile or posted to FLEX’s online message center
                (if applicable). To the extent permissible under Applicable Law, any electronic
                communication you send to FLEX will not be effective until FLEX has had a
                reasonable opportunity to act on the electronic communication. You should not
                rely on electronic communication if you need to communicate with FLEX
                immediately and, in no event, should your sole method of communication with
                FLEX regarding any emergency be by electronic communication. FLEX strongly
                suggests that you report all matters requiring immediate attention to FLEX by
                calling <span style='background:yellow;mso-highlight:yellow'>[INSERT PHONE
                NUMBER</span>]. FLEX may require you to provide written confirmation of any
                verbal or electronic notice of alleged error by FLEX.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(g)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>PERMISSIBLE
                ACTIVITIES.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'> You
                may perform the following activities with the Online Service:</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l15 level1 lfo16;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Account Inquiry.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> You may retrieve Account
                information (such as a balance due) and view up to six (6) months of
                transactions.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l16 level1 lfo17;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Alerts.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> You may set alert messages for
                certain circumstances, such as when a new statement is available for viewing or
                when a pending payment has posted to your Account.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l17 level1 lfo18;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Review Statements.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> You may view electronic version of
                up to six (6) months of Account statements. Online statements should not be
                substituted for, nor represented as, your official statement.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l18 level1 lfo19;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Bill Payments.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> You may make payments to your
                Account from your Payment Account. Bill Payments may only be made from
                checking, money market, or savings accounts and must be made in accordance with
                the terms of these Terms and any other applicable account agreements.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(h)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>PAYMENTS.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> You authorize FLEX to debit your
                Payment Account and remit funds on your behalf to the Payee. When FLEX receives
                a Payment Instruction, you have authorized FLEX to debit your Payment Account
                and remit funds on your behalf so that the funds arrive as close as reasonably
                possible to the Payment Due Date as designated by you. You also authorize FLEX
                to credit your Payment Account for payments returned to you FLEX.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(i)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>CANCELLING/MODIFYING
                PENDING BILL PAYMENTS.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>
                The delete/edit function applies to payments initiated through the Online
                Service that are pending. There is no charge for cancelling or modifying a
                Pending Bill Payment. Other than as described above, you may not stop or edit a
                bill payment.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(j)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>DISCLOSURE
                OF ACCOUNT INFORMATION.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>
                FLEX will not disclose any information to third parties about you, including
                email addresses, or your Account, except in the situations described below or
                as otherwise set forth in FLEX’s Privacy Policy located at
                www.flexinc.us/privacy]. We will disclose such information:</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l19 level1 lfo20;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>where
                disclosure is necessary for completing payments, or to resolve a problem
                related to a payment;</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l20 level1 lfo21;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>to
                verify the condition and existence of your Account for a third party, such as a
                credit bureau or merchant;</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l21 level1 lfo22;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>to
                persons authorized by law in the course of their official duties;</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l22 level1 lfo23;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>to
                a consumer reporting agency as defined by Applicable Law;</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l23 level1 lfo24;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>to
                comply with a government agency or court order, such as a lawful subpoena;</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l24 level1 lfo25;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>to
                FLEX employees, auditors, service providers, attorneys or collection agents in
                the course of their duties; or</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l25 level1 lfo26;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>if
                you give FLEX written permission (including by email).</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(k)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>INSUFFICIENT
                FUNDS TO COMPLETE BILL PAYMENT.</span></b><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial;color:black'> You must have sufficient available funds in your Payment
                Account on the Payment Due Date. If your Payment Account has insufficient
                funds, the Bill Payment will not be completed. Should a Bill Payment fail
                because of insufficient funds in your Payment Account, an amount equal to
                FLEX’s Returned Payment Fee then in effect will be applied to your Account.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(l)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>FLEX’S
                LIABILITY FOR FAILURE TO COMPLETE BILL PAYMENTS.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> If FLEX debits your Payment Account
                incorrectly, FLEX will be responsible for returning the improperly debited
                funds to your Payment Account. If FLEX does not complete a Bill Payment from
                your Payment Account on time or in the correct amount in accordance with your
                Payment Instructions, FLEX will be liable for the actual charges incurred by
                you, to the extent required by Applicable Law and in any event subject to
                paragraph 5 herein. However, FLEX will not be liable in the following
                situations:</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l26 level1 lfo27;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>You
                did not properly follow the provisions of these Terms, the online instructions
                for the Online Service, or other instructions for making a payment;</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l27 level1 lfo28;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>Through
                no fault of FLEX’s, you have insufficient funds in your Payment Account to make
                a payment;</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l28 level1 lfo29;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>Your
                computer, the software, phone lines, FLEX’s computer system or the Online
                Service were not working properly or were temporarily unavailable, and this
                problem was or reasonably should have been apparent to you when you attempted
                the payment or you were advised by the Online Service of the malfunction before
                you executed the payment;</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l29 level1 lfo30;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>Circumstances
                beyond our control prevented the payment, despite reasonable precautions that
                we have taken, including telecommunications outages, fires, floods, or other
                natural disasters;</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l30 level1 lfo31;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>FLEX
                has reasonable basis to believe that unauthorized use of your UserID, Password,
                or User Account or Account has occurred or may be occurring;</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l31 level1 lfo32;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>FLEX
                or you <span class=GramE>has</span> terminated your Online Service or closed
                your Account to which the UserID was linked;</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l32 level1 lfo33;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>You
                have supplied your login information to another party; or</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:74.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l33 level1 lfo34;tab-stops:list 74.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>For
                any other reason specified in these Terms or any other agreement FLEX has with
                you.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(m)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>ACCURATE
                INFORMATION.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'> In
                creating and using your User Account on the Web Site, you agree to: (<span
                class=SpellE>i</span>) provide true, accurate, current and complete information
                about yourself on any registration form required on the Web Site (such
                information being the “Registration Data”); and (ii) maintain and promptly
                update the Registration Data to keep it true, accurate, current and complete.
                If you provide any information that is untrue, inaccurate, not current or
                incomplete, or FLEX has reasonable grounds to suspect that such information is
                untrue, inaccurate, not current or incomplete, FLEX has the right to suspend or
                terminate your User Account and refuse any and all current or future use of
                your User Account.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(n)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>TERMINATION
                OF ACCOUNT.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'> FLEX
                reserves the right to terminate your use of the Online Service for any reason
                including inactivity and at any time without notice to you. You have the right
                to terminate your use of the Online Service by writing to FLEX at the address
                provided at the end of these Terms. Any termination of your use of the Online
                Service, whether initiated by you or by FLEX, will not affect any of your or
                FLEX’s rights and obligations under these Terms that have arisen before the
                effective date of such termination.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(o)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>RELATED
                AGREEMENTS.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'> Your
                Account linked to the Online Service will also be governed by the agreements,
                disclosures, FLEX’s service tariff in your area, and other documents provided
                to you in connection with the opening of your Account, as they may be amended
                periodically. If any inconsistency exists between such other documentation and
                these Terms, then these Terms shall control to the extent of inconsistency.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l1 level1 lfo2;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(p)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>ERRORS
                OR QUESTIONS ABOUT BILL PAYMENTS.</span></b><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial;color:black'> In case of errors or questions about Bill Payments, you
                should notify FLEX at once at by email at <span style='background:yellow;
                mso-highlight:yellow'>______________________@______________________</span>.com,
                or through the online message center (if applicable).</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l0 level1 lfo1;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'><span
                style='mso-spacerun:yes'> </span>4.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>DISCLAIMERS.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l34 level1 lfo35;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(a)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>NO
                WARRANTIES; INDEMNIFICATION.</span></b><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial;color:black'> YOU EXPRESSLY AGREE THAT YOUR USE OF THE WEB SITE IS AT
                YOUR SOLE RISK. THE WEB SITE, THE ONLINE SERVICE AND THE CONTENT IS PROVIDED
                “AS IS” AND “AS AVAILABLE” FOR YOUR USE, WITHOUT WARRANTIES OF ANY KIND, EITHER
                EXPRESS OR IMPLIED, UNLESS SUCH WARRANTIES ARE LEGALLY INCAPABLE OF EXCLUSION.
                FLEX PROVIDES THE WEB SITE AND THE ONLINE SERVICE ON A COMMERCIALLY REASONABLE
                BASIS AND FLEX MAKES NO REPRESENTATIONS OR WARRANTIES THAT THE WEB SITE, THE
                ONLINE SERVICE, THE CONTENT OR ANY SERVICES OFFERED IN CONNECTION WITH THE WEB
                SITE ARE OR SHALL REMAIN UNINTERRUPTED OR ERROR-FREE, THE CONTENT SHALL BE
                NON-INFRINGING ON ANY THIRD PARTY’S INTELLECTUAL PROPERTY RIGHTS, THAT DEFECTS
                SHALL BE CORRECTED, THAT THE WEB PAGES ON THE WEB SITE, THE ONLINE SERVICE, ANY
                ELECTRONIC COMMUNICATION OR THE SERVERS USED IN CONNECTION WITH THE WEB SITE
                ARE OR SHALL REMAIN FREE FROM ANY VIRUSES, WORMS, TIME BOMBS, DROP DEAD
                DEVICES, TROJAN HORSES OR OTHER HARMFUL COMPONENTS, OR THAT ANY PERSON USING
                THE WEB SITE WILL BE THE PERSON THAT HE OR SHE REPRESENTS HIMSELF OR HERSELF TO
                BE. FLEX DOES NOT GUARANTEE THAT YOU WILL BE ABLE TO ACCESS OR USE THE WEB SITE
                AND/OR THE ONLINE SERVICE AT TIMES OR LOCATIONS OF YOUR CHOOSING, OR THAT FLEX
                SHALL HAVE ADEQUATE CAPACITY FOR THE WEB SITE AND/OR THE ONLINE SERVICE AS A
                WHOLE OR IN ANY SPECIFIC GEOGRAPHIC AREA.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l34 level1 lfo35;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(b)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>INDEMNIFICATION.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> You agree to defend, indemnify and
                hold FLEX and its affiliates, subsidiaries, owners, directors, officers,
                employees and agents harmless from and against any and all claims, demands,
                suits, proceedings, liabilities, judgments, losses, damages, expenses and costs
                (including without limitation reasonable attorneys’ fees) assessed or incurred
                by FLEX, directly or indirectly, with respect to or arising out of: (<span
                class=SpellE>i</span>) your failure to comply with these Terms; (ii) your
                breach of your obligations under these Terms; (iii) your use of the rights
                granted hereunder, including without limitation any claims made by any third
                parties; and/or (iv) your violation of any third party right, including without
                limitation any copyright, property, or privacy right.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l34 level1 lfo35;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(c)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>NOT
                INVESTMENT ADVICE.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>
                FLEX DOES NOT INTEND TO PROVIDE ANY INVESTMENT ADVICE OR INFORMATION RELATING
                TO ITSELF OR ANY FLEX IDENTIFIED ON THE WEB SITE. Nevertheless, the Web Site
                may, from time to time, contain information on the current or prospective
                financial condition of this and/or certain other companies. FLEX cautions that
                there are various important factors that could cause actual results to differ
                materially from those indicated in the information you may encounter on the Web
                Site. Accordingly, there can be no assurance that such indicated results will
                be realized. These factors include, among other things, legislative and
                regulatory initiatives regarding regulation of American companies doing
                business abroad; political and economic conditions and developments in the
                United States and in foreign countries in which the companies discussed on the
                Web Site operate; financial market conditions and the results of financing
                efforts; and changes in commodity prices and interest rates.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l0 level1 lfo1;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'><span
                style='mso-spacerun:yes'> </span>5.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>LIMITATION OF LIABILITY.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> FLEX’S ENTIRE LIABILITY AND YOUR
                EXCLUSIVE REMEDY WITH RESPECT TO THE USE OF THE WEB SITE, THE ONLINE SERVICE
                AND/OR ANY SERVICE PROVIDED IN CONNECTION WITH THE WEB SITE SHALL BE THE
                CANCELLATION OF YOUR USER ACCOUNT WITH FLEX. EXCEPT FOR THE ACTUAL CHARGES
                DESCRIBED IN PARAGRAPH 3(L) ABOVE, IN NO EVENT WILL FLEX BE LIABLE FOR ANY
                DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, PUNITIVE OR CONSEQUENTIAL
                DAMAGES ARISING FROM YOUR USE OF THE WEB SITE AND/OR ANY SERVICE PROVIDED IN
                CONNECTION WITH THE WEB SITE, THE ONLINE SERVICE AND/OR ANY SERVICE PROVIDED IN
                CONNECTION WITH THE WEB SITE, OR FOR ANY OTHER CLAIM RELATED IN ANY WAY TO YOUR
                USE OF THE WEB SITE, THE ONLINE SERVICE AND/OR ANY SERVICE PROVIDED IN
                CONNECTION WITH THE WEB SITE, INCLUDING, BUT NOT LIMITED TO, (A) ERRORS, MISTAKES,
                OR INACCURACIES OF CONTENT, (B) PERSONAL INJURY OR PROPERTY DAMAGE, OF ANY
                NATURE WHATSOEVER, RESULTING FROM YOUR ACCESS TO AND USE OF THE WEB SITE, THE
                ONLINE SERVICE AND/OR ANY SERVICE PROVIDED IN CONNECTION WITH THE WEB SITE, (C)
                ANY UNAUTHORIZED ACCESS TO OR USE OF OUR COMPUTER SERVERS AND/OR ANY AND ALL
                PERSONAL INFORMATION AND/OR FINANCIAL INFORMATION STORED THEREIN, (D) ANY
                INTERRUPTION OR CESSATION OF TRANSMISSION TO OR FROM THE WEB SITE, THE ONLINE
                SERVICE AND/OR ANY SERVICE PROVIDED IN CONNECTION WITH THE WEB SITE, AND/OR (E)
                ANY VIRUSES, WORMS, TIME BOMBS, DROP DEAD DEVICES, TROJAN HORSES OR OTHER
                HARMFUL COMPONENTS THAT MAY BE TRANSMITTED TO OR THROUGH THE WEB SITE, THE
                ONLINE SERVICE AND/OR ANY SERVICE PROVIDED IN CONNECTION WITH THE WEB SITE BY
                ANY THIRD PARTY OR FOR ANY LOSS OR DAMAGE OF ANY KIND. BECAUSE SOME STATES OR
                JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF LIABILITY FOR
                CONSEQUENTIAL OR INCIDENTAL DAMAGES, IN SUCH STATES OR JURISDICTIONS FLEX’S
                LIABILITY WILL BE LIMITED TO THE GREATEST EXTENT PERMITTED BY LAW.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l0 level1 lfo1;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'><span
                style='mso-spacerun:yes'> </span>6.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>PRIVACY.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> Personal data that you provide
                regarding yourself will be handled in accordance with FLEX’s Privacy Policy
                located at www.flexinc.us/privacy.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l0 level1 lfo1;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'><span
                style='mso-spacerun:yes'> </span>7.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>THIRD PARTY CONTENT.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l35 level1 lfo36;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(a)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>FLEX may provide hyperlinks to other
                web sites maintained by third parties, or FLEX may provide third party content
                on the Web Site by framing or other methods. THE LINKS TO THIRD PARTY WEB SITES
                ARE PROVIDED FOR YOUR CONVENIENCE AND INFORMATION ONLY. THE CONTENT ON ANY
                LINKED WEB SITE IS NOT UNDER FLEX’S CONTROL AND FLEX IS NOT RESPONSIBLE FOR THE
                CONTENT OF LINKED WEB SITES, INCLUDING ANY FURTHER LINKS CONTAINED IN A <span
                class=GramE>THIRD PARTY</span> WEB SITE. IF YOU DECIDE TO ACCESS ANY OF THE <span
                class=GramE>THIRD PARTY</span> WEB SITES LINKED TO THE WEB SITE, YOU DO SO
                ENTIRELY AT YOUR OWN RISK.</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:56.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l35 level1 lfo36;tab-stops:list 56.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>(b)<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp; </span></span></span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>If a <span class=GramE>third party</span>
                links to the Web Site, it is not necessarily an indication of an endorsement,
                authorization, sponsorship, affiliation, joint venture or partnership by or
                with FLEX. In most cases, FLEX is not even aware that a third party has linked
                to the Web Site. A web site that links to the Web Site: (<span class=SpellE>i</span>)
                may link to, but not replicate, FLEX’s Content; (ii) may not create a browser,
                border environment or frame FLEX’s Content; (iii) may not imply that FLEX is
                endorsing it or its products; (iv) may not misrepresent its relationship with
                FLEX; (v) may not present false or misleading information about FLEX’s products
                or services; and (vi) should not include content that could be construed as
                distasteful, offensive or controversial, and should contain only Content that
                is appropriate for all age groups.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l0 level1 lfo1;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'><span
                style='mso-spacerun:yes'> </span>8.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>COPYRIGHT AND TRADEMARKS.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> The trademarks, service marks and
                logos used and displayed on the Web Site are FLEX’s, or its subsidiaries’ or
                affiliates’, registered and unregistered trademarks. FLEX is the copyright
                owner or authorized licensee of all text and all graphics contained on the Web
                Site. All trademarks and service marks of FLEX that may be referred to on the
                Web Site are the property of FLEX. Other parties’ trademarks and service marks
                that may be referred to on the Web Site are the property of their respective
                owners. Nothing on the Web Site should be construed as granting, by
                implication, estoppel or otherwise, any license or right to use any of FLEX’s
                trademarks or service marks without FLEX’s prior written permission. FLEX
                aggressively enforces its intellectual property rights. Neither the name of
                FLEX nor any of FLEX other trademarks, service marks or copyrighted materials
                may be used in any way, including in any advertising, hyperlink, publicity or
                promotional materials of any kind, whether relating to the Web Site or
                otherwise, without FLEX’s prior written permission, except that a third party
                web site that desires to link to the Web Site and that complies with the
                requirements of Paragraph 7(b) above may use the name “FLEX” in or as part of
                that URL link. If you believe that any Content on the Web Site violates any
                intellectual property right of yours, please contact FLEX at the address, email
                address or telephone number set forth at the bottom of these Terms.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l0 level1 lfo1;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'><span
                style='mso-spacerun:yes'> </span>9.<span style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;
                </span></span></span><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>LOCAL LAWS.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> FLEX makes no representation that
                content or materials in the Web Site are appropriate or available for use in
                jurisdictions outside the United States. Access to the Web Site from
                jurisdictions where such access is illegal is prohibited. If you choose to
                access the Web Site from other jurisdictions, you do so on your own initiative
                and are responsible for compliance with applicable local laws. FLEX is not
                responsible for any violation of law. You may not use or export the Content or
                materials in the Web Site in violation of U.S. export laws and regulations. You
                agree that the Web Site, these Terms and the Online Service shall be
                interpreted and governed in accordance with federal law and, to the extent not
                preempted by federal law, with the laws of the state where FLEX maintains your
                Account, or, if FLEX transfers your Account to another location, where FLEX
                currently maintains your Account. The Web Site and the Online Service shall be
                deemed a passive website and service that does not give rise to personal
                jurisdiction over FLEX, either specific or general, in jurisdictions other than
                the states covered by the preceding sentence. You agree and hereby submit to
                the exclusive personal jurisdiction of the state and federal courts located
                where FLEX maintains your Account, or, if FLEX transfers your Account to
                another location, where FLEX currently maintains your Account. You further
                agree to comply with all applicable laws regarding the transmission of
                technical data exported from the United States and the country in which you reside
                (if different from the United States).</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l36 level1 lfo37;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>10.<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>AVAILABILITY.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> Information that FLEX publishes in
                the Web Site may contain references or cross-references to products, programs
                or services of FLEX that are not necessarily announced or available in your
                area. Such references do not mean that FLEX will announce any of those
                products, programs or services in your area at any time in the future. You
                should contact FLEX for information regarding the products, programs and
                services that may be available to you, if any.</span><span style='font-size:
                10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l37 level1 lfo38;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>11.<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>NON-TRANSFERABILITY
                OF USER ACCOUNT.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>
                User Accounts and <span class=SpellE>UserIDs</span> are non-transferable, and
                all users are obligated to take preventative measures to prohibit unauthorized
                users from accessing the Web Site with his or her UserID and password. You may
                not assign these Terms, in whole or in part, or delegate any of your
                responsibilities hereunder to any third party. Any such attempted assignment or
                delegation will not be recognized by FLEX unless acknowledge by FLEX in
                writing. FLEX has no obligation to provide you with written acknowledgment.
                FLEX may, at any time and in its sole discretion, assign these Terms, in whole
                or in part, or delegate any of our rights and responsibilities under these
                Terms to any third party or entity.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l38 level1 lfo39;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>12.<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>TERMINATION
                OF SERVICE.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'> We
                may terminate your User Account or right to access secured portions of the Web
                Site at any time, without notice, for conduct that we believe violates these
                Terms and/or is harmful to other users of the Web Site, to FLEX, to the
                business of the Web Site’s Internet service provider, or to other information
                providers.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l39 level1 lfo40;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>13.<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>CUSTOMER
                COMMENTS.</span></b><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'> We
                welcome the submission of comments, information or feedback through the Web
                Site. By submitting information through the Web Site, you agree that the
                information submitted shall be subject to the FLEX Web Site Privacy Policy
                located at www.flexinc.us/privacy.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l40 level1 lfo41;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>14.<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp; </span></span></span><b
                style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>MISCELLANEOUS.</span></b><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'> If any provision of these Terms is
                deemed invalid by a court of competent jurisdiction, the invalidity of such
                provision shall not affect the validity of the remaining provisions of these
                Terms, which shall remain in full force and effect. No waiver of any term of
                these Terms shall be deemed a further or continuing waiver of such term or any
                other term, and FLEX’s failure to assert any right or provision under these
                Terms shall not constitute a waiver of such right or provision. These Terms and
                the FLEX Web Site Privacy Policy located at www.flexinc.us/privacy are the
                entire agreement between you and FLEX with respect to your use of the Web Site
                and the Online Service, and supersede any and all prior communications and
                prior agreements, whether written or oral, between you and FLEX regarding the
                Web Site and the Online Service.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal align=center style='margin-top:12.0pt;text-align:center;
                line-height:13.0pt'><b style='mso-bidi-font-weight:normal'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Your Consent <span class=GramE>To</span>
                This Agreement</span></b><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>By accessing and
                using the Web Site, you consent to and agree to be bound by the terms of the
                foregoing Terms. If we decide to change these Terms, we will make an effort to
                post those changes on the web page so that you will always be able to
                understand the terms and conditions that apply to your use of the Web Site
                and/or the Online Service. Your use of the Web Site and/or the Online Service
                following any amendment of these Terms will signify your assent to and
                acceptance of its revised terms.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>If you have
                additional questions or comments of any kind, or if you see anything on the Web
                Site that you think is inappropriate, please let us know by email
                www.flexinc.us/privacy or by sending your comments to:</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal align=center style='margin-top:6.0pt;text-align:center;
                line-height:13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>FLEX</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal align=center style='margin-top:6.0pt;text-align:center;
                line-height:13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black;
                background:yellow;mso-highlight:yellow'>______________________</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;background:yellow;mso-highlight:yellow'><o:p></o:p></span></p>
                
                <p class=MsoNormal align=center style='margin-top:6.0pt;text-align:center;
                line-height:13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black;
                background:yellow;mso-highlight:yellow'>______________________</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;background:yellow;mso-highlight:yellow'><o:p></o:p></span></p>
                
                <p class=MsoNormal align=center style='margin-top:6.0pt;text-align:center;
                line-height:13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black;
                background:yellow;mso-highlight:yellow'>Attn: ______________________</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;background:yellow;mso-highlight:yellow'><o:p></o:p></span></p>
                
                <p class=MsoNormal align=center style='margin-top:6.0pt;text-align:center;
                line-height:13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black;
                background:yellow;mso-highlight:yellow'>(XXX) XXX-XXXX</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;background:yellow;mso-highlight:yellow'><o:p></o:p></span></p>
                
                <p class=MsoNormal align=center style='margin-top:6.0pt;text-align:center;
                line-height:13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black;
                background:yellow;mso-highlight:yellow'>XXXX@______________________.com</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal align=center style='margin-top:6.0pt;text-align:center;
                line-height:13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>EFFECTIVE
                AS OF: June 28, 2019</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal align=center style='margin-top:6.0pt;text-align:center;
                line-height:13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>LAST
                UPDATED: June 28, 2019</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><b style='mso-bidi-font-weight:normal'><i style='mso-bidi-font-style:
                normal'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>Privacy and
                Information Security Policy</span></i></b><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>Flex,
                Inc.(“FLEX”) is committed to safeguarding your online privacy with respect to
                the personally identifiable information that we may obtain from you at the
                http://www.flexinc.us web site (the “Web Site”). Our Privacy and Information
                Security Policy (“Privacy Policy”) answers frequently asked questions about
                your online privacy, including what personally identifiable information we may
                obtain from you and how it will be used and protected. FLEX may from time to
                time change this Privacy Policy, so please check back periodically.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><i style='mso-bidi-font-style:normal'><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial;color:black'>WHAT PERSONALLY IDENTIFIABLE INFORMATION DO WE OBTAIN FROM
                YOU? WHEN DO WE OBTAIN SUCH INFORMATION?</span></i><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial;color:black'> </span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>If, upon visiting
                our Web Site, your use is limited to browsing our informational content, we
                will not require that you provide us with any personally identifiable
                information. However, we may request personal information from you at other
                times. For example:</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l41 level1 lfo42;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>If
                you report a problem or submit a customer review, we will ask that you provide
                your name, e-mail address, membership number, address, phone number and fax
                number. Should you contact us for any reason other than to report a problem
                and/or submit a review, we may also keep a record and/or copy of your
                correspondence with us.</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><i style='mso-bidi-font-style:normal'><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial;color:black'>HOW DO WE PROTECT THE SECURITY AND QUALITY OF YOUR PERSONAL
                INFORMATION?</span></i><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='text-align:justify;line-height:13.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span
                style='mso-spacerun:yes'> </span>To protect the security and quality of your
                personal information, we have implemented technical and managerial procedures
                to maintain accurate, current and complete information as well as to protect
                your personal information against loss, misuse or alteration when it is under
                our control. Your personally identifiable information will be encrypted and
                stored on our secured servers. Your personal information is also password
                protected so that access is limited to yourself and those with whom you share
                your password, FLEX, as well as third party access facilitated by FLEX with
                your prior permission. We have also taken steps to help protect the integrity
                of your personal financial information when you complete a purchase transaction
                on our Web Site. </span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>HOW DO WE USE
                YOUR INFORMATION?</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:3.0pt;text-align:justify;line-height:13.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Our primary use of your information
                is to administer, maintain and improve your experience on our Web Site
                generally as well as provide you with customized, personalization services and
                interactive communications.</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l42 level1 lfo43;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>If
                you check the “opt-in” feature on our Web Site, or if you do not uncheck a
                pre-checked “opt-in” box we may from time to time send you e-mails regarding
                our Web Site and special promotions. Also, we occasionally may send you direct
                mail about products or services that we believe may be of interest to you.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l43 level1 lfo44;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>We
                use your financial information (e.g., your credit card number) only to verify
                your credit and to bill you for transactions entered into through our Web Site.
                We also use your contact information as necessary to send you information about
                the transactions that you have entered into on our Web Site.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l44 level1 lfo45;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>When
                you enter any sweepstakes, contests or promotions sponsored by us or by one of
                our business partners, we may use your e-mail address to send you status
                updates.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l45 level1 lfo46;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>We
                use your IP address to help diagnose problems with our server and to administer
                the services offered on our Web Site. We also use your IP address to help
                identify you and to gather broad demographic information that we may share with
                our business partners, but only in the aggregate without any of your personally
                identifiable information.</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l46 level1 lfo47;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>We
                may research the demographics, interests and behavior of our customers based on
                the information provided to us during membership registration, during
                sweepstakes, contests and promotions, from our server log files, from cookies
                and from surveys. Our research may be compiled and analyzed on an aggregate
                basis. We may share this aggregate data with business partners, but only in the
                aggregate, without any of your personally identifiable information.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>CAN YOU “OPT-OUT”
                OF RECEIVING COMMUNICATIONS FROM FLEX?</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:3.0pt;text-align:justify;line-height:13.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>If you change your mind and decide
                that you no longer want to receive promotional e-mails and/or direct mailings,
                you may opt-out at any time by simply sending an e-mail request to <span
                style='background:yellow;mso-highlight:yellow'>______________________ @______________________.com</span>.
                Similarly, if you are not receiving our promotional e-mails and/or direct
                mailings and wish to receive these materials, you may opt-in at any time by
                simply sending an e-mail request to <span style='background:yellow;mso-highlight:
                yellow'>______________________ @______________________.com</span>.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>PRIVACY POLICIES
                OF FLEX PARTNERS</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:3.0pt;text-align:justify;line-height:13.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Third parties that have links on our
                Web Site may collect personally identifiable information about you. We are not
                responsible for the privacy policies or practices of such sites and the
                practices of these sites are not governed by this Privacy Policy. If you have
                questions about the privacy policies or practices of a <span class=GramE>third
                party</span> site, you should contact the site administrator or web-master of
                the specific site. We may from time to time partner with other companies to offer
                co-branded services as well as sweepstakes, contests and promotions. Any
                information that you provide in connection with the co-branded services or any
                jointly sponsored sweepstakes, contests or promotions will become the joint
                property of FLEX and its business partners. We will maintain your information
                in accordance with the terms of this Privacy Policy. However, this Privacy
                Policy does not govern the privacy policies and practices of our business
                partners. If you have questions about the privacy policies or practices of our
                business partners, you should contact them directly.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>DO WE SELL OR
                RENT YOUR PERSONALLY IDENTIFIABLE INFORMATION?</span><span style='font-size:
                10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:3.0pt;text-align:justify;line-height:13.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>No, as a general rule, we do not
                sell or rent your personally identifiable information to <span class=SpellE>any
                one</span>. If and whenever we intend to share your personally identifiable
                information with a third party (other than to a business partner as provided
                herein), you will be notified at the time of data collection or transfer, and
                you will have the option of not permitting the transfer. However, we may from
                time to time rent or sell demographic information in the aggregate that does
                not contain your personally identifiable information.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>WITH WHOM DO WE
                SHARE INFORMATION?</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:3.0pt;text-align:justify;line-height:13.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>We generally will not disclose any
                of your personally identifiable information except when we have your permission
                to do so or under some special circumstances described below.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l47 level1 lfo48;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>As
                noted previously, we may from time to time partner with other companies to
                offer co-branded services as well as sweepstakes, contests or promotions. Any
                information that you provide in connection with the co-branded services or any
                jointly sponsored sweepstakes, contests or promotions will become the joint
                property of FLEX and its business partners. We may also disclose other personal
                information about you to our business partners, but only if we have obtained
                your permission to make the disclosure before data collection or before
                transferring the data.</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l48 level1 lfo49;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>We
                may, from time to time, offer you the opportunity to receive materials or
                special offers from third parties. If you want to receive this information, we
                may (but only with your permission) share your name and e-mail address with
                them.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l49 level1 lfo50;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>Under
                confidentiality agreements, we may match user information with third party
                data. We also may disclose aggregate demographic and/or user information and
                statistics in order to describe our customer base to prospective partners and
                other third parties, and for other lawful purposes.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l50 level1 lfo51;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>We
                may disclose your personally identifiable information without your prior
                permission in special cases. For example, we may have reason to believe that
                disclosing the information is necessary to identify, contact or bring legal
                action against someone who may be violating the User Terms and Conditions, or
                may be causing intentional or unintentional injury or interference to the
                rights or property of FLEX or any third party, including other customers. Also,
                we may disclose or access your personally identifiable information when we
                believe in good faith that law or regulation requires disclosure.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>HOW CAN YOU
                UPDATE, CORRECT OR DELETE YOUR PERSONALLY IDENTIFIABLE INFORMATION?</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:3.0pt;text-align:justify;line-height:13.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>You may edit your personally
                identifiable information and your password at any time by sending an e-mail
                request to <span style='background:yellow;mso-highlight:yellow'>______________________
                @______________________.com</span>.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>WHAT ARE COOKIES?
                HOW DO WE USE COOKIES?</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:3.0pt;text-align:justify;line-height:13.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Cookies enable us to customize and
                personalize your experience on our Web Site, including the products and
                promotions that are offered to you. Essentially, a cookie is a small amount of
                data that is sent to your browser from a web server and is stored on your
                computer’s hard drive. We use cookies for several purposes in connection with
                the operation of our Web Site</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l51 level1 lfo52;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>We
                may use cookies to identify you and access your information stored on our
                computers in order to deliver you a better and more personalized experience.
                For example, we may use cookies to tell you about products and services
                specific to your interests.</span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l52 level1 lfo53;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>Upon
                request, we will save your “user name” so that you do not have to re-enter it
                every time you visit our Web Site. In providing you with this service, we use
                cookies.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l53 level1 lfo54;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>We
                may use cookies to estimate our customer base and customer usage patterns. Each
                browser accessing our Web Site may use given a unique cookie that is then used
                to determine the extent of repeat visits and the customer activity during those
                visits. We may use the historical information to help target promotions based
                on customer interests and behavior, both specifically to individual customers
                and on an aggregate basis with respect to all customers.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                margin-left:38.0pt;margin-bottom:.0001pt;text-align:justify;text-indent:-20.0pt;
                line-height:13.0pt;mso-list:l54 level1 lfo55;tab-stops:list 38.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'><span style='mso-list:Ignore'>•<span
                style='font:7.0pt "Times New Roman"'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </span></span></span><span style='font-size:10.0pt;mso-bidi-font-size:
                12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>We
                also may use cookies to track your progress and number of entries in some
                promotions, sweepstakes and contests, or through a meeting registration
                process. For example, when a promotion uses cookies, the information coded to
                the cookie indicates your progress through the promotion, and may be used to
                track entries, submissions and status of prize drawings.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>Business partners
                that offer co-branded services and jointly-sponsored sweepstakes, contests and
                promotions on our Web Site, may use their own cookies. We have no control over
                those cookies, nor does this Privacy Policy cover how your personal information
                contained in those cookies may be used or protected. If you have any questions
                about the cookies of such third parties, or about the use of your personal
                information by such third parties, you should contact the site administrator or
                web-master of the <span class=GramE>third party</span> site.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>DO YOU HAVE CHOICES
                ABOUT COOKIES?</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:3.0pt;text-align:justify;line-height:13.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>Yes, you have several choices with
                respect to cookies. You can modify your browser preferences to accept all
                cookies, to notify you when a cookie is set, or to reject all cookies. However,
                our Web Site uses cookie-based authentication. Accordingly, if you choose to
                reject all cookies, you may not be able to log onto our Web Site and/or use our
                services or participate in our sweepstakes, contests or promotions.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>WHAT ELSE SHOULD
                YOU KNOW ABOUT YOUR ONLINE PRIVACY?</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:3.0pt;text-align:justify;line-height:13.0pt'><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial;color:black'>It is important to remember that
                whenever you voluntarily disclose personal information on-line, your
                information can be collected and used by others. If you transmit or post
                personal information on-line that is accessible to others, you will not be able
                to control how that information is used by others. When we receive the
                transmitted information, we will use the procedures summarized in this Privacy
                Policy to ensure the integrity and security of that information in our systems.
                Unfortunately, notwithstanding any of the steps taken by us, it is not possible
                to guarantee the security and integrity of data transmitted over the Internet.
                Consequently, while we take the above-described reasonable steps to protect
                your personal information, we cannot and do not warrant the security or
                integrity of any information you transmit to us when registering for our Web
                Site or otherwise. All such transmission of information is at your own risk.
                Moreover, though we are committed to having our Web Site comply with this Privacy
                Policy, you are ultimately responsible for maintaining the secrecy of your
                password and your personally identifiable information. If you are careless with
                your password, or you decide to share your password with third parties, you
                must be aware of the risk that such third parties will have access to all your
                personally identifiable information.</span><span style='font-size:10.0pt;
                mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>CONTACT US.</span><span
                style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                
                <p class=MsoNormal style='margin-top:10.0pt;text-align:justify;line-height:
                13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>If you have any
                questions or comments about this Privacy Statement or the practices of our Web
                Site, please feel free to e-mail us at <span style='background:yellow;
                mso-highlight:yellow'>______________________@______________________.com</span>
                or visit our contact page.<o:p></o:p></span></p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
            </div><!-- /.modal-content -->
          </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->
        
        <div class="modal fade" id="policy" tabindex="-1" role="dialog">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h4 class="modal-title">Privacy Policy</h4>
              </div>
              <div class="modal-body">
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.25in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><b
                    style='mso-bidi-font-weight:normal'><span style='font-size:10.0pt;mso-bidi-font-size:
                    12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>PRIVACY
                    POLICY</span></b><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>Effective as of June 27, 2019</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.25in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>This privacy policy (the “Privacy
                    Policy”) applies to the FLEX mobile application (the “App”), owned and operated
                    by FLEX INC. (“FLEX,” “we,” “us,” or “our”). We have created this Privacy
                    Policy to tell you what information the App collects, how we use that
                    information, and who we will share that information with, if at all. This
                    Privacy Policy does not address the privacy practices of any third parties that
                    we do not own, control, or are affiliated with. Capitalized terms not defined
                    in this Privacy Policy will have the meaning set forth in our Terms of Use. By
                    visiting and/or using our App, you are agreeing to the terms of this Privacy
                    Policy and the accompanying Terms of Use. We encourage you to read the Privacy
                    Policy, and to use the information it contains to help you make informed
                    decisions.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt;
                    mso-outline-level:1'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>1. <b
                    style='mso-bidi-font-weight:normal'>INFORMATION WE COLLECT OR RECEIVE</b> </span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>In the course of operating the App,
                    we will collect and/or receive the following types of information. You
                    authorize us to collect and/or receive such information.</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>a. <u>Personal Information.</u> We
                    only receive or collect information that identifies you personally if you
                    choose to provide such personally identifiable information to us via the App or
                    other means. When you sign up to become a user or contact us, you will be
                    required to provide us with personal information about yourself (collectively,
                    the “Personal Information”). Such Personal Information may include your name,
                    e-mail address, physical address, phone number, email address, social security
                    number or tax identification number, driver’s license number and expiration
                    date, personal photograph or likeness, vehicle identification information
                    including plate number, geolocational data, socio-demographic information, and persistent
                    identifiers associated with consumer device or precise location data of
                    individual or mobile device. We do not collect any Personal Information from
                    you when you use the App unless you provide us with the Personal Information
                    voluntarily.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>b. <u>Third-party Log In.</u> If you
                    sign in through any third-party site, you are authorizing us to collect, store,
                    and use, in accordance with this Privacy Policy, any and all information that
                    you agreed that third-party would provide to us through the third-party’s
                    Application Programming Interface (“API”). Such information may include,
                    without limitation, your first and last name, username, profile picture,
                    headline, unique identifier and access token, and e-mail address.</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>c. <u>Payment Information.</u> If
                    you choose to make a purchase or subscribe to a feature or service ours that
                    requires a fee, you will be required to provide us with your payment
                    information, including, without limitation, bank account numbers, credit card
                    or debit card numbers, account details, ACH information, and similar data
                    (collectively, “Payment Information”). Such Payment Information will be
                    collected and processed by our third-party payment vendors pursuant to the
                    terms and conditions of their privacy policies and terms of use, and we do not
                    obtain access to any Payment Information in connection with such purchases or
                    subscriptions.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>d. <u>Geolocational Information. </u>Certain
                    features and functionalities of the App are based on your location. In order to
                    provide these features and functionalities while you are using your mobile
                    device, we may, with your consent, automatically collect geolocational
                    information from your mobile device or wireless carrier and/or certain
                    third-party service providers (collectively, “<u>Geolocational Information</u>”).
                    Collection of such Geolocational Information occurs only when the App is
                    running on your device. You may decline to allow us to collect such
                    Geolocational Information, in which case we will not be able to provide certain
                    features or functionalities to you.</span><span style='font-size:10.0pt;
                    mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>e. <u>Third-Party Analytics.</u> We
                    and the third-party technology providers, ad exchanges, ad networks,
                    advertisers, agencies, ad exchanges, and ad servers with which we work use
                    third-party analytics services (e.g., Google Analytics) to evaluate your use of
                    the App, compile reports on activity, collect demographic data, analyze
                    performance metrics, and collect and evaluate other information relating to the
                    App and mobile and Internet usage. These third parties use cookies and other
                    technologies to help analyze and provide us the data. You consent to the
                    processing of data about you by these analytics providers in the manner and for
                    the purposes set out in this Privacy Policy. For more information on these
                    third parties, including how to opt out from certain data collection, please
                    visit <a style='mso-comment-reference:DS_1;mso-comment-date:20190627T0836'><span
                    style='background:yellow;mso-highlight:yellow'>[insert FLEX WEBSITE].</span>
                    Please </a></span><span class=MsoCommentReference><span style='font-size:8.0pt'><a
                    class=msocomanchor id="_anchor_1"
                    onmouseover="msoCommentShow('_anchor_1','_com_1')"
                    onmouseout="msoCommentHide('_com_1')" href="#_msocom_1" language=JavaScript
                    name="_msoanchor_1">[DS1]</a><span style='mso-special-character:comment'>&nbsp;</span></span></span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>be advised that if you opt out of
                    any such service, you may not be able to use the full functionality of the App.</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>f. <u>Other Information.</u> In
                    addition to the Personal Information, Payment Information, and Geolocational
                    Information, we may automatically collect or receive additional information
                    regarding you and your use of the App; your interactions with us and our
                    advertising; and information regarding your computer and mobile devices used to
                    access the App (collectively, the “Other Information”). Such <u>Other
                    Information</u> may include:</span><span style='font-size:10.0pt;mso-bidi-font-size:
                    12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.25in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    class=SpellE><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>i</span></span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>. <u>From You.</u> Additional
                    information about yourself that you voluntarily provide to us, such as your
                    gender and your product and service preferences.</span><span style='font-size:
                    10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.25in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>ii. <u>From Your Activity</u>. We
                    may collect or receive information regarding:</span><span style='font-size:
                    10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>A. IP address, which may consist of
                    a static or dynamic IP address and will sometimes point to a specific
                    identifiable computer or mobile device;</span><span style='font-size:10.0pt;
                    mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>B. browser type and language;</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>C. referring and exit pages and
                    URLs;</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                    "Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>D. date and time; and</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>E. details regarding your activity
                    on the App, such as search queries and other performance and usage data.</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.25in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>iii. About Your Mobile Device. We
                    may collect or receive information regarding:</span><span style='font-size:
                    10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>A. type of mobile device;</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>B. advertising Identifier (“IDFA” or
                    “ADID”);</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>C. operating system and version
                    (e.g., iOS, Android or Windows);</span><span style='font-size:10.0pt;
                    mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>D. carrier; and</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>E. network type (WIFI, 3G, 4G, LTE).</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.25in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>iv. <u>From Cookies.</u> We may use
                    both session cookies, which expire once you close the App, and persistent
                    cookies, which stay on your mobile device until you delete them and other
                    technologies to help us collect data and to enhance your experience with the
                    App. Cookies are small text files an app can use to recognize a repeat visitor
                    to the app. We may use cookies for various purposes, including to:</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>A. type of mobile device;</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>B. personalize your experience;</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>C. analyze which portions of the App
                    are visited and used most frequently; and</span><span style='font-size:10.0pt;
                    mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>D. measure and optimize advertising
                    and promotional effectiveness.</span><span style='font-size:10.0pt;mso-bidi-font-size:
                    12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>If you do not want us to deploy
                    cookies in the App, you can opt out by setting your mobile device to reject
                    cookies. You can still use the App if you choose to disable cookies, although
                    your ability to use some of the features may be affected.</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt;
                    mso-outline-level:1'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>2. <b
                    style='mso-bidi-font-weight:normal'>INFORMATION COLLECTED BY OR THROUGH
                    THIRD-PARTY ADVERTISING COMPANIES</b> </span><span style='font-size:10.0pt;
                    mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>We may share Other Information about
                    your activity on the App with third parties for ad distribution and ad
                    optimization (defined as the tailoring, targeting (i.e., behavioral,
                    contextual, retargeting, analyzing, managing, reporting, and optimizing of
                    ads). These third parties may use cookies, pixel tags (also called web beacons
                    or clear gifs), and/or other technologies to collect Other Information for such
                    purposes. Pixel tags enable us and these third-party advertising companies to
                    recognize a browser’s cookie when a browser visits the site on which the pixel
                    tag is located in order to learn which advertisement brings a user to a given
                    site. In addition, we may receive Other Information from advertisers and/or
                    their service providers such as advertising identifiers, IP addresses, and
                    post-conversion data.</span><span style='font-size:10.0pt;mso-bidi-font-size:
                    12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt;
                    mso-outline-level:1'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>3. <b
                    style='mso-bidi-font-weight:normal'>HOW TO OPT OUT OF THIRD-PARTY
                    INTEREST-BASED ADVERTISING</b> </span><span style='font-size:10.0pt;mso-bidi-font-size:
                    12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>If you wish to opt out of
                    third-party interest-based advertising, please visit
                    http://www.networkadvertising.org and http://www.aboutads.info/choices for
                    details on how to do so. Additionally, users of mobile Devices can follow the
                    below instructions:</span><span style='font-size:10.0pt;mso-bidi-font-size:
                    12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><u><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>Android Users</span></u><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.25in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>For Android devices with OS 2.2 and
                    up and Google Play Services version 4.0 and up: Open your Google Settings app;
                    Ads; Enable “<span class=SpellE>Opt</span> out of interest-based advertising.”</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><u><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>iOS Users</span></u><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.25in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>iOS 7 or Higher: Go to your
                    Settings; Select Privacy; Select Advertising; Enable the “Limit Ad Tracking”
                    setting.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:10.0pt;margin-right:0in;margin-bottom:
                    0in;margin-left:1.25in;margin-bottom:.0001pt;text-align:justify;line-height:
                    13.0pt'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                    "Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>iOS 6: Go to your
                    Settings; Select General; Select About; Select Advertising; Enable the “Limit
                    Ads Tracking” setting.</span><span style='font-size:10.0pt;mso-bidi-font-size:
                    12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt;
                    mso-outline-level:1'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>4. <b
                    style='mso-bidi-font-weight:normal'>HOW INFORMATION IS USED AND SHARED</b> </span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>a. You authorize us to use the
                    Personal Information, Payment Information, Geolocational Information, and the
                    Other Information (collectively, the “Information”) to:</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    class=SpellE><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>i</span></span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>. <span class=GramE>provide</span>
                    and improve our App;</span><span style='font-size:10.0pt;mso-bidi-font-size:
                    12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>ii. provide our services;</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>iii. administer our promotional
                    programs;</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>iv. solicit your feedback; and</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>v. <span class=GramE>inform</span>
                    you about our products and services.</span><span style='font-size:10.0pt;
                    mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>b. In order to provide our services
                    and administer our promotional programs, we may share the Information with our
                    third-party promotional and marketing partners, including, without limitation,
                    businesses participating in our various programs.</span><span style='font-size:
                    10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>c. We engage third-party companies
                    and individuals to perform functions on our behalf. Examples may include
                    providing technical assistance, customer service, marketing assistance, and
                    administration of promotional programs. These other companies will have access
                    to the Information only as necessary to perform their functions and to the
                    extent permitted by law</span><span style='font-size:10.0pt;mso-bidi-font-size:
                    12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>d. In an ongoing effort to better
                    understand our users, the App, and our products and services, we may analyze
                    certain Information in anonymized and aggregate form to operate, maintain,
                    manage, and improve the App and/or such products and services. This aggregate
                    information does not identify you personally. We may share and/or license this
                    aggregate data to our affiliates, agents, business and promotional partners,
                    and other third parties. We may also disclose aggregated user statistics to
                    describe the App and these products and services to current and prospective
                    business partners and investors and to other third parties for other lawful
                    purposes.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>e. We may share some or all of your
                    Information with any of our parent companies, subsidiaries, joint ventures, or
                    other companies under common control with us.</span><span style='font-size:
                    10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>f. As we develop our businesses, we
                    might sell or buy businesses or assets. In the event of a corporate sale,
                    merger, reorganization, sale of assets, dissolution, or similar event, the
                    Information may be part of the transferred assets.</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>g. To the extent permitted by law,
                    we may also disclose the Information:</span><span style='font-size:10.0pt;
                    mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    class=SpellE><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>i</span></span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>. when required by law, court order,
                    or other government or law enforcement authority or regulatory agency; or</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:1.0in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>ii. whenever we believe that
                    disclosing such Information is necessary or advisable, for example, to protect
                    the rights, property, or safety of us or others, including you.</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt;
                    mso-outline-level:1'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>5. <b
                    style='mso-bidi-font-weight:normal'>ACCESSING AND MODIFYING INFORMATION AND COMMUNICATION
                    PREFERENCES</b> </span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>If you have provided us any Personal
                    Information, you may access, remove, review, and/or make changes to the same by
                    contacting us as set forth below. In addition, you may manage your receipt of
                    marketing and non-transactional communications by clicking on the “unsubscribe”
                    link located on the bottom of any of our marketing e-mails. We will use
                    commercially reasonable efforts to process such requests in a timely manner.
                    You should be aware, however, that it is not always possible to completely
                    remove or modify information in our subscription databases. You cannot opt out
                    of receiving transactional e-mails related to the App (e.g., requests for
                    support).</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>We may also deliver notifications to
                    your mobile device (e.g., push notifications). You can disable these
                    notifications by deleting the relevant service or by changing the settings on
                    your mobile device.</span><span style='font-size:10.0pt;mso-bidi-font-size:
                    12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt;
                    mso-outline-level:1'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>6. <b
                    style='mso-bidi-font-weight:normal'>HOW WE PROTECT YOUR INFORMATION</b> </span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>We take commercially reasonable
                    steps to protect the Information from loss, misuse, and unauthorized access,
                    disclosure, alteration, or destruction. Please understand, however, that no
                    security system is impenetrable. We cannot guarantee the security of our
                    databases or the databases of the third parties with which we may share such
                    Information, nor can we guarantee that the Information you supply will not be
                    intercepted while being transmitted over the Internet. In particular, e-mail
                    sent to us may not be secure, and you should therefore take special care in
                    deciding what information you send to us via e-mail.</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt;
                    mso-outline-level:1'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>7. <b
                    style='mso-bidi-font-weight:normal'>IMPORTANT NOTICES TO NON-U.S. RESIDENTS</b>
                    </span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:
                    "Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>The App and its servers are operated
                    in the United States. If you are located outside of the United States, please
                    be aware that your Information, including your Personal Information, may be transferred
                    to, processed, maintained, and used on computers, servers, and systems located
                    outside of your state, province, country, or other governmental jurisdiction
                    where the privacy laws may not be as protective as those in your jurisdiction.
                    If you are located outside the United States and choose to use the App, you
                    hereby irrevocably and unconditionally consent to such transfer, processing,
                    and use in the United States and elsewhere.</span><span style='font-size:10.0pt;
                    mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt;
                    mso-outline-level:1'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>8. <b
                    style='mso-bidi-font-weight:normal'>APP STORES; EXTERNAL WEBSITES</b> </span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>Your app store (e.g., iTunes or Google
                    Play) may collect certain information in connection with your use of the App,
                    such as Personal Information, Payment Information, Geolocational Information,
                    and other usage-based data. We have no control over the collection of such
                    information by a third-party app store, and any such collection or use will be
                    subject to that third party’s applicable privacy policies.</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>The App may contain links to
                    third-party websites. We have no control over the privacy practices or the
                    content of these websites. As such, we are not responsible for the content or
                    the privacy policies of those third-party websites. You should check the
                    applicable third-party privacy policy and terms of use when visiting any other
                    websites.</span><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt;
                    mso-outline-level:1'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>9. <b
                    style='mso-bidi-font-weight:normal'>CHILDREN</b> </span><span style='font-size:
                    10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>The App is not directed to children
                    under the age of 13. We adhere to the Children’s Online Privacy Protection Act
                    (COPPA) and will not knowingly collect Personal Information from any child
                    under the age of 13. We ask that minors (under the age of 13) not use the App.
                    If a child under the age of 13 has provided us with Personal Information, a
                    parent or guardian of that child may contact us and request that such
                    information be deleted from our records.</span><span style='font-size:10.0pt;
                    mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt;
                    mso-outline-level:1'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>10. <b
                    style='mso-bidi-font-weight:normal'>CHANGES TO THIS PRIVACY POLICY</b> </span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>This Privacy Policy is effective as
                    of the date stated at the top of this Privacy Policy. We may change this
                    Privacy Policy from time to time. Any such changes will be posted on the App.
                    By accessing the App after we make any such changes to this Privacy Policy, you
                    are deemed to have accepted such changes. Please be aware that, to the extent
                    permitted by applicable law, our use of the Information is governed by the
                    Privacy Policy in effect at the time we collect the Information. Please refer
                    back to this Privacy Policy on a regular basis.</span><span style='font-size:
                    10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;mso-fareast-font-family:
                    Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.5in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt;
                    mso-outline-level:1'><span style='font-size:10.0pt;mso-bidi-font-size:12.0pt;
                    font-family:"Arial",sans-serif;mso-fareast-font-family:Arial;color:black'>11. <b
                    style='mso-bidi-font-weight:normal'>HOW TO CONTACT US</b> </span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
                    
                    <p class=MsoNormal style='margin-top:6.0pt;margin-right:0in;margin-bottom:0in;
                    margin-left:.75in;margin-bottom:.0001pt;text-align:justify;line-height:13.0pt'><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>If you have questions about this
                    Privacy Policy, please e-mail us at <a style='mso-comment-reference:DS_2;
                    mso-comment-date:20190627T0833'><span style='background:yellow;mso-highlight:
                    yellow'>[insert e-mail address]</span> </a></span><span
                    class=MsoCommentReference><span style='font-size:8.0pt'><a
                    class=msocomanchor id="_anchor_2"
                    onmouseover="msoCommentShow('_anchor_2','_com_2')"
                    onmouseout="msoCommentHide('_com_2')" href="#_msocom_2" language=JavaScript
                    name="_msoanchor_2">[DS2]</a><span style='mso-special-character:comment'>&nbsp;</span></span></span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial;color:black'>with “Privacy Policy” in the subject
                    line or mail us at the following address: <span style='background:yellow;
                    mso-highlight:yellow'>[insert mailing address]</span>.</span><span
                    style='font-size:10.0pt;mso-bidi-font-size:12.0pt;font-family:"Arial",sans-serif;
                    mso-fareast-font-family:Arial'><o:p></o:p></span></p>
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
              </div>
            </div><!-- /.modal-content -->
          </div><!-- /.modal-dialog -->
        </div><!-- /.modal -->


        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="js/jquery-3.2.1.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <!-- Rev slider js -->
        <script src="vendors/revolution/js/jquery.themepunch.tools.min.js"></script>
        <script src="vendors/revolution/js/jquery.themepunch.revolution.min.js"></script>
        <script src="vendors/revolution/js/extensions/revolution.extension.actions.min.js"></script>
        <script src="vendors/revolution/js/extensions/revolution.extension.video.min.js"></script>
        <script src="vendors/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
        <script src="vendors/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
        <script src="vendors/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
        <script src="vendors/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
        <!-- Extra plugin css -->
        <script src="vendors/counterup/jquery.waypoints.min.js"></script>
        <script src="vendors/counterup/jquery.counterup.min.js"></script>
        <script src="vendors/counterup/apear.js"></script>
        <script src="vendors/counterup/countto.js"></script>
        <script src="vendors/owl-carousel/owl.carousel.min.js"></script>
        <script src="vendors/parallaxer/jquery.parallax-1.1.3.js"></script>
        <!--Tweets-->
        <script src="vendors/tweet/tweetie.min.js"></script>
        <script src="vendors/tweet/script.js"></script>

        <script src="js/theme.js"></script>
        
        <script src="https://www.eventbrite.com/static/widgets/eb_widgets.js"></script>
        <script type="text/javascript">
            function submitEmail() {
                var email = $('#emailText').val();
            
                jQuery.post('/submission.php', {
                    email: email
                },function(data){alert(data);
                    //$('#submissionResponse').html(data);
                });
            
            }
            function privacy() {
                $("#policy").modal('show');
            }
            function terms() {
                $("#terms_modal").modal('show');
            }
            var exampleCallback = function() {
                console.log('Order complete!');
            };
        
            window.EBWidgets.createWidget({
                // Required
                widgetType: 'checkout',
                eventId: '65365972383',
                iframeContainerId: 'eventbrite-widget-container-65365972383',
        
                // Optional
                iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
                onOrderComplete: exampleCallback  // Method called when an order has successfully completed
            });
        </script>
        
    </body>
</html>
